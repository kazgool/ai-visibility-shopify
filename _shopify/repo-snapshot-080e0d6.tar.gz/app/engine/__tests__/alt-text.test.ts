import { describe, expect, it } from "vitest";
import { buildAltText, looksLikeFilename, ALT_MAX_CHARS , looksLikeMachineAlt } from "../alt-text";

const facts = [
  { k: "Material", v: "lemn masiv, catifea" },
  { k: "Culoare", v: "negru" },
  { k: "Dimensiuni", v: "280 x 280 cm" },
  { k: "Camera", v: "living" },
];

describe("looksLikeFilename", () => {
  it("recognises camera filenames", () => {
    expect(looksLikeFilename("DSC_4471")).toBe(true);
    expect(looksLikeFilename("IMG-2043.jpg")).toBe(true);
    expect(looksLikeFilename("image_123650291")).toBe(true);
    expect(looksLikeFilename("")).toBe(true);
  });

  it("recognises UUIDs and migration identifiers", () => {
    expect(looksLikeFilename("B6ADC692-C01B-4229-8956-100A9AFB8C46")).toBe(true);
    expect(looksLikeFilename("3ba7dee8f7bd4e1496cf6e31548bbe11")).toBe(true);
  });

  it("leaves real descriptions alone", () => {
    expect(looksLikeFilename("Coltar Chesterfield negru din catifea")).toBe(false);
    expect(looksLikeFilename("Masa extensibila 160 cm")).toBe(false);
  });
});

describe("imported catalogues", () => {
  it("decodes HTML entities in the title", () => {
    const alt = buildAltText(
      { title: "Set Masa &#038; 6 Scaune &#8211; Beige", productType: null },
      [],
      0,
    );
    expect(alt).toBe("Set Masa & 6 Scaune - Beige");
    expect(alt).not.toContain("&#");
  });

  it("never puts an identifier in the description", () => {
    const polluted = [{ k: "Material", v: "B6ADC692-C01B-4229-8956-100A9AFB8C46" }];
    const alt = buildAltText({ title: "Set Masa", productType: null }, polluted, 0);
    expect(alt).not.toContain("B6ADC692");
  });
});

describe("buildAltText", () => {
  const product = { title: "Coltar Chesterfield Negru", productType: "Coltar" };

  it("describes what the picture shows, not the whole catalogue entry", () => {
    const alt = buildAltText(product, facts, 0);
    expect(alt).toContain("Coltar Chesterfield Negru");
    expect(alt.toLowerCase()).toContain("lemn masiv");
  });

  it("never exceeds the character cap", () => {
    const long = [{ k: "Material", v: "x".repeat(300) }];
    expect(buildAltText(product, long, 0).length).toBeLessThanOrEqual(ALT_MAX_CHARS);
  });

  it("gives gallery images distinct text", () => {
    const first = buildAltText(product, facts, 0);
    const third = buildAltText(product, facts, 2);
    expect(first).not.toBe(third);
  });

  it("ignores attributes that say nothing about the image", () => {
    const alt = buildAltText(product, [{ k: "Warranty", v: "2 years" }], 0);
    expect(alt).not.toContain("2 years");
  });

  it("falls back to the title when nothing is visual", () => {
    expect(buildAltText(product, [], 0)).toBe("Coltar Chesterfield Negru");
  });
});

describe("looksLikeMachineAlt", () => {
  it("catches an embedded filename inside otherwise readable text", () => {
    expect(
      looksLikeMachineAlt("Set Masa & 6 Scaune - Negru - Photoroom_20260527_163158, stofa"),
    ).toBe(true);
  });

  it("catches HTML entities nobody typed", () => {
    expect(looksLikeMachineAlt("Set Masa &amp; 6 Scaune &#8211; Negru")).toBe(true);
  });

  it("catches an embedded UUID", () => {
    expect(looksLikeMachineAlt("Masa - 596BB88F-AF51-4CB4-9437-BD76349CBC2B")).toBe(true);
  });

  it("leaves a real human description alone", () => {
    expect(looksLikeMachineAlt("Masa ovala cu blat lucios si sase scaune negre")).toBe(false);
  });

  it("leaves our own current output alone", () => {
    expect(looksLikeMachineAlt("Set Masa & 6 Scaune - Negru - lucios, negru, view 2")).toBe(false);
  });

  // PRD-FIX-WAVE-1 E5. A digit run on its own was permission to overwrite a
  // human description that happened to carry a product code. One junk signal
  // is not evidence; two are.
  it("keeps a description that merely carries a product code", () => {
    expect(looksLikeMachineAlt("Masa extensibila, cod 20260527, stejar natural")).toBe(false);
  });

  it("keeps a plain human description", () => {
    expect(looksLikeMachineAlt("Fotoliu gri, vedere laterala")).toBe(false);
  });

  it("still replaces a camera filename", () => {
    expect(looksLikeMachineAlt("IMG_20260527_120033.jpg")).toBe(true);
  });

  it("still replaces a bare timestamp", () => {
    expect(looksLikeMachineAlt("20260527120033")).toBe(true);
  });

  it("still replaces a tool-generated filename", () => {
    expect(looksLikeMachineAlt("photoroom_1748.png")).toBe(true);
  });
});

describe("descriptors are cut on the joiner, not on a decimal comma", () => {
  it("takes the whole first value when it carries a decimal comma", () => {
    const alt = buildAltText({ title: "Pachet" }, [{ k: "Size", v: "29,7 g, 390 g" }]);
    expect(alt).toContain("29,7 g");
    // "29" alone is not a descriptor of anything, and it was what a screen
    // reader used to be handed.
    expect(alt).not.toBe("Pachet - 29");
  });
});
