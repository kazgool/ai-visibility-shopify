// graphile-worker runner (ARCHITECTURE §1). Runs in its own Fly process
// group, next to the database, so bulk passes survive a closed browser tab.

import { run } from "graphile-worker";
import * as tasks from "./tasks";
import { describeGraphqlError } from "../app/services/graphql-errors";

async function main() {
  const runner = await run({
    connectionString: process.env.DATABASE_URL,
    concurrency: 2,
    pollInterval: 2000,
    taskList: {
      bulk_extract: tasks.bulk_extract,
      extract_product: tasks.extract_product,
      bulk_alt_text: tasks.bulk_alt_text,
      poll_changes: tasks.poll_changes,
      sweep_missing: tasks.sweep_missing,
      reconcile_mirrors: tasks.reconcile_mirrors,
      crawler_check: tasks.crawler_check,
      bulk_collections: tasks.bulk_collections,
      seo_watch: tasks.seo_watch,
      seo_scan_products: tasks.seo_scan_products,
      seo_snapshot: tasks.seo_snapshot,
      seo_queue_build: tasks.seo_queue_build,
      seo_apply: tasks.seo_apply,
      seo_collection_queue: tasks.seo_collection_queue,
      seo_collection_apply: tasks.seo_collection_apply,
      prune_crawler_hits: tasks.prune_crawler_hits,
    },
    // Freshness in layers: webhooks fire instantly, the poll closes the gap
    // when one is dropped, the sweep guarantees nothing is missed for long.
    crontab: [
      "*/15 * * * * poll_changes",
      "30 3 * * 1 sweep_missing", // Monday 03:30 UTC
      "0 4 * * 1 seo_watch", // Monday 04:00 UTC, seo_unlocked shops only
      "45 3 * * * seo_scan_products", // nightly 03:45 UTC, after the Monday sweep starts
      "0 5 * * * prune_crawler_hits", // daily 05:00 UTC, PRIVACY.md 30-day retention
    ].join("\n"),
  });
  await runner.promise;
}

main().catch((err) => {
  // The formatter, not the object: a boot failure on a Shopify call used to
  // print a Response at Node's default depth and say nothing.
  console.error(describeGraphqlError(err, "worker boot"));
  process.exit(1);
});
